# Why Does Loneliness Hurt So Much?

- `frames/` — 124 final frames, 001–124 in edit order
- `thumbnail/` — THUMB-1 (main, "ALONE = DEATH?") and THUMB-2 (A/B test, "THEY WERE NEVER ALONE"), 1280×720
- `audio/VOICEOVER-EN-full.mp3` — full English voiceover, 8:31, pauses included
- `audio/blocks/` — 21 blocks separately; text in `audio/voiceover-text.md`
- Final video: `видео/Loneliness-EN-1080p.mp4` in the repo (51 MB)

Title: Why Does Loneliness Hurt So Much?
